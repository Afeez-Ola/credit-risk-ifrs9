namespace CreditRisk.Ifrs9.Configuration;

/// <summary>
/// Central configuration, the C# counterpart of config.py: paths, feature lists,
/// leakage controls, split date, and IFRS 9 assumptions.
/// </summary>
public sealed class PipelineConfig
{
    public string DataDirectory { get; init; } = "data";
    public string ReportsDirectory { get; init; } = "reports";
    public string SourceFileName { get; init; } = "loan.csv";

    public string SourcePath => Path.Combine(DataDirectory, SourceFileName);

    /// <summary>
    /// Loans issued on or after this date form the out-of-time test set. Training
    /// uses older vintages only, mirroring how a deployed model is actually used.
    /// </summary>
    public DateOnly OutOfTimeSplit { get; init; } = new(2016, 10, 1);

    /// <summary>Loan statuses treated as resolved outcomes.</summary>
    public IReadOnlyList<string> ResolvedStatuses { get; init; } =
        new[] { "Fully Paid", "Charged Off" };

    /// <summary>
    /// Post-origination fields that must never reach the model. Payment, recovery,
    /// hardship and settlement information would leak the outcome.
    /// </summary>
    public IReadOnlyList<string> LeakageColumns { get; init; } = new[]
    {
        "total_pymnt", "total_rec_prncp", "total_rec_int", "recoveries",
        "collection_recovery_fee", "last_pymnt_amnt", "last_pymnt_d",
        "next_pymnt_d", "hardship_flag", "settlement_status", "days_past_due",
        "outstanding_balance"
    };

    public IReadOnlyList<string> NumericFeatures { get; init; } = new[]
    {
        "loan_amnt", "int_rate", "annual_inc", "dti", "delinq_2yrs", "term"
    };

    public IReadOnlyList<string> CategoricalFeatures { get; init; } = new[]
    {
        "grade", "purpose"
    };

    // IFRS 9 assumptions. Assumption based rather than modelled from recovery data.
    public double LossGivenDefault { get; init; } = 0.65;
    public double CreditConversionFactor { get; init; } = 1.0;
    public double DiscountRate { get; init; } = 0.08;

    /// <summary>Absolute PD increase that triggers a move to Stage 2.</summary>
    public double SicrAbsoluteThreshold { get; init; } = 0.05;

    /// <summary>Relative PD deterioration (multiple of origination PD) triggering Stage 2.</summary>
    public double SicrRelativeThreshold { get; init; } = 2.0;

    /// <summary>Days past due backstop for Stage 2.</summary>
    public int SicrDaysPastDueBackstop { get; init; } = 30;

    /// <summary>Days past due at which an exposure is credit impaired.</summary>
    public int DefaultDaysPastDue { get; init; } = 90;

    public void EnsureDirectories()
    {
        Directory.CreateDirectory(DataDirectory);
        Directory.CreateDirectory(ReportsDirectory);
    }
}
