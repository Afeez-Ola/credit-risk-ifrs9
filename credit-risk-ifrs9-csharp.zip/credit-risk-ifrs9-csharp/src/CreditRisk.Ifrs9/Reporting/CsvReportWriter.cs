using System.Globalization;
using System.Text;
using CreditRisk.Ifrs9.Pipeline;

namespace CreditRisk.Ifrs9.Reporting;

/// <summary>Writes the pipeline outputs to the reports directory.</summary>
public sealed class CsvReportWriter
{
    private readonly string _directory;

    public CsvReportWriter(string directory)
    {
        _directory = directory;
        Directory.CreateDirectory(_directory);
    }

    public void WriteEclSummary(PipelineContext context)
    {
        var builder = new StringBuilder("stage,loan_count,total_exposure,total_ecl,coverage_ratio\n");

        foreach (var summary in context.StageSummaries)
        {
            builder.AppendLine(string.Join(",",
                summary.Stage,
                summary.LoanCount.ToString(CultureInfo.InvariantCulture),
                summary.TotalExposure.ToString("F2", CultureInfo.InvariantCulture),
                summary.TotalEcl.ToString("F2", CultureInfo.InvariantCulture),
                summary.CoverageRatio.ToString("F4", CultureInfo.InvariantCulture)));
        }

        File.WriteAllText(Path.Combine(_directory, "ecl_summary.csv"), builder.ToString());
    }

    public void WriteMetrics(PipelineContext context)
    {
        var builder = new StringBuilder("metric,value\n");

        foreach (var (metric, value) in context.Metrics.OrderBy(m => m.Key))
            builder.AppendLine($"{metric},{value.ToString("F6", CultureInfo.InvariantCulture)}");

        File.WriteAllText(Path.Combine(_directory, "model_metrics.csv"), builder.ToString());
    }

    public void WriteCoefficients(IReadOnlyDictionary<string, double> coefficients)
    {
        var builder = new StringBuilder("feature,coefficient\n");

        foreach (var (feature, weight) in coefficients.OrderByDescending(c => Math.Abs(c.Value)))
            builder.AppendLine($"{feature},{weight.ToString("F6", CultureInfo.InvariantCulture)}");

        File.WriteAllText(Path.Combine(_directory, "pd_coefficients.csv"), builder.ToString());
    }
}
