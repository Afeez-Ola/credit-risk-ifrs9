using CreditRisk.Ifrs9.Configuration;
using CreditRisk.Ifrs9.Domain;

namespace CreditRisk.Ifrs9.Staging;

/// <summary>
/// Stage allocation with the usual three tests: a credit-impaired test, a relative
/// and absolute PD deterioration test, and a days-past-due backstop.
/// </summary>
public sealed class SicrPolicy : ISicrPolicy
{
    private readonly PipelineConfig _config;

    public SicrPolicy(PipelineConfig config) => _config = config;

    public Ifrs9Stage Assign(ScoredLoan scored)
    {
        ArgumentNullException.ThrowIfNull(scored);
        var loan = scored.Loan;

        // Stage 3: credit impaired.
        if (loan.DaysPastDue >= _config.DefaultDaysPastDue)
            return Ifrs9Stage.Stage3;

        // Stage 2: significant increase in credit risk since origination.
        var absoluteIncrease = scored.PdLifetime - scored.PdAtOrigination;
        var relativeIncrease = scored.PdAtOrigination > 1e-9
            ? scored.PdLifetime / scored.PdAtOrigination
            : 1.0;

        if (absoluteIncrease >= _config.SicrAbsoluteThreshold ||
            relativeIncrease >= _config.SicrRelativeThreshold ||
            loan.DaysPastDue >= _config.SicrDaysPastDueBackstop)
            return Ifrs9Stage.Stage2;

        return Ifrs9Stage.Stage1;
    }
}
