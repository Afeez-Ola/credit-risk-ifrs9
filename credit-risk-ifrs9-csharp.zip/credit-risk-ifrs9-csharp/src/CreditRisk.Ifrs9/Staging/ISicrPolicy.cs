using CreditRisk.Ifrs9.Domain;

namespace CreditRisk.Ifrs9.Staging;

/// <summary>
/// Decides the IFRS 9 stage of an exposure. Isolated behind an interface because
/// SICR rules are a policy choice that institutions calibrate differently.
/// </summary>
public interface ISicrPolicy
{
    Ifrs9Stage Assign(ScoredLoan loan);
}
