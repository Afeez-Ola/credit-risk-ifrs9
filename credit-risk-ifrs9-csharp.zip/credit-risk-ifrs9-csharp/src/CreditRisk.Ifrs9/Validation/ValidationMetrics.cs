using CreditRisk.Ifrs9.Exceptions;

namespace CreditRisk.Ifrs9.Validation;

/// <summary>A decile of the score distribution with predicted against observed default rates.</summary>
public sealed record CalibrationBin(
    int Decile,
    int Count,
    double MeanPredicted,
    double ObservedRate)
{
    public double Difference => ObservedRate - MeanPredicted;
}

/// <summary>
/// Discrimination, calibration and stability measures, the C# counterpart of
/// 06_validation.py.
/// </summary>
public static class ValidationMetrics
{
    /// <summary>
    /// Area under the ROC curve, computed from the rank-sum identity so the cost is
    /// O(n log n) rather than the O(n^2) of pairwise comparison. Ties share ranks.
    /// </summary>
    public static double AreaUnderCurve(IReadOnlyList<double> scores, IReadOnlyList<int> labels)
    {
        Validate(scores, labels);

        var positives = labels.Count(l => l == 1);
        var negatives = labels.Count - positives;

        if (positives == 0 || negatives == 0)
            throw new DataValidationException("AUC requires both positive and negative cases.");

        var ranks = AverageRanks(scores);
        var positiveRankSum = 0d;

        for (var i = 0; i < labels.Count; i++)
            if (labels[i] == 1) positiveRankSum += ranks[i];

        return (positiveRankSum - positives * (positives + 1) / 2.0) / ((double)positives * negatives);
    }

    public static double Gini(IReadOnlyList<double> scores, IReadOnlyList<int> labels)
        => 2.0 * AreaUnderCurve(scores, labels) - 1.0;

    /// <summary>Kolmogorov-Smirnov: the largest gap between the good and bad score distributions.</summary>
    public static double KolmogorovSmirnov(IReadOnlyList<double> scores, IReadOnlyList<int> labels)
    {
        Validate(scores, labels);

        var ordered = scores
            .Select((score, i) => (score, label: labels[i]))
            .OrderBy(x => x.score)
            .ToList();

        double positives = labels.Count(l => l == 1);
        double negatives = labels.Count - positives;

        if (positives == 0 || negatives == 0)
            throw new DataValidationException("KS requires both positive and negative cases.");

        double cumulativePositive = 0, cumulativeNegative = 0, maxGap = 0;

        foreach (var (_, label) in ordered)
        {
            if (label == 1) cumulativePositive++; else cumulativeNegative++;
            maxGap = Math.Max(maxGap, Math.Abs(cumulativePositive / positives - cumulativeNegative / negatives));
        }

        return maxGap;
    }

    /// <summary>
    /// Population Stability Index between a reference and a comparison distribution.
    /// Below 0.10 is stable; 0.10 to 0.25 warrants monitoring; above 0.25 signals a shift.
    /// </summary>
    public static double PopulationStabilityIndex(
        IReadOnlyList<double> reference,
        IReadOnlyList<double> comparison,
        int bins = 10)
    {
        if (reference.Count == 0 || comparison.Count == 0)
            throw new DataValidationException("PSI requires non-empty distributions.");
        if (bins < 2)
            throw new ArgumentOutOfRangeException(nameof(bins), "At least two bins are required.");

        var cutPoints = Quantiles(reference, bins);
        var referenceShares = BinShares(reference, cutPoints);
        var comparisonShares = BinShares(comparison, cutPoints);

        const double floor = 1e-6;
        var psi = 0d;

        for (var i = 0; i < referenceShares.Length; i++)
        {
            var expected = Math.Max(referenceShares[i], floor);
            var actual = Math.Max(comparisonShares[i], floor);
            psi += (actual - expected) * Math.Log(actual / expected);
        }

        return psi;
    }

    /// <summary>
    /// Splits the book into score deciles and compares mean predicted PD with the
    /// observed default rate, the check that surfaced under-prediction in the mid
    /// deciles of the later vintages.
    /// </summary>
    public static IReadOnlyList<CalibrationBin> CalibrationTable(
        IReadOnlyList<double> predictions,
        IReadOnlyList<int> labels,
        int bins = 10)
    {
        Validate(predictions, labels);

        var ordered = predictions
            .Select((p, i) => (prediction: p, label: labels[i]))
            .OrderBy(x => x.prediction)
            .ToList();

        var table = new List<CalibrationBin>();
        var size = (int)Math.Ceiling(ordered.Count / (double)bins);

        for (var bin = 0; bin < bins; bin++)
        {
            var slice = ordered.Skip(bin * size).Take(size).ToList();
            if (slice.Count == 0) continue;

            table.Add(new CalibrationBin(
                Decile: bin + 1,
                Count: slice.Count,
                MeanPredicted: slice.Average(x => x.prediction),
                ObservedRate: slice.Average(x => (double)x.label)));
        }

        return table;
    }

    private static void Validate(IReadOnlyList<double> scores, IReadOnlyList<int> labels)
    {
        ArgumentNullException.ThrowIfNull(scores);
        ArgumentNullException.ThrowIfNull(labels);

        if (scores.Count != labels.Count)
            throw new DataValidationException("Scores and labels must have equal length.");
        if (scores.Count == 0)
            throw new DataValidationException("Cannot compute metrics on an empty sample.");
    }

    private static double[] AverageRanks(IReadOnlyList<double> values)
    {
        var indexed = values
            .Select((value, index) => (value, index))
            .OrderBy(x => x.value)
            .ToList();

        var ranks = new double[values.Count];
        var position = 0;

        while (position < indexed.Count)
        {
            var last = position;
            while (last + 1 < indexed.Count &&
                   Math.Abs(indexed[last + 1].value - indexed[position].value) < 1e-12)
                last++;

            var averageRank = (position + last + 2) / 2.0; // ranks are 1-based
            for (var k = position; k <= last; k++)
                ranks[indexed[k].index] = averageRank;

            position = last + 1;
        }

        return ranks;
    }

    private static double[] Quantiles(IReadOnlyList<double> values, int bins)
    {
        var sorted = values.OrderBy(v => v).ToArray();
        var cutPoints = new double[bins - 1];

        for (var i = 1; i < bins; i++)
        {
            var position = (int)Math.Floor(i / (double)bins * (sorted.Length - 1));
            cutPoints[i - 1] = sorted[Math.Clamp(position, 0, sorted.Length - 1)];
        }

        return cutPoints;
    }

    private static double[] BinShares(IReadOnlyList<double> values, IReadOnlyList<double> cutPoints)
    {
        var counts = new int[cutPoints.Count + 1];

        foreach (var value in values)
        {
            var bin = 0;
            while (bin < cutPoints.Count && value > cutPoints[bin]) bin++;
            counts[bin]++;
        }

        return counts.Select(c => c / (double)values.Count).ToArray();
    }
}
