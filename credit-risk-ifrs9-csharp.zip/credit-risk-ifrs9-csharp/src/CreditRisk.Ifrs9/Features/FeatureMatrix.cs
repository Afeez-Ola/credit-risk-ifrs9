namespace CreditRisk.Ifrs9.Features;

/// <summary>A design matrix with named columns and an aligned target vector.</summary>
public sealed class FeatureMatrix
{
    public FeatureMatrix(IReadOnlyList<string> columnNames, double[][] rows, int[] target)
    {
        if (rows.Length != target.Length)
            throw new ArgumentException("Row count and target length must match.");

        ColumnNames = columnNames;
        Rows = rows;
        Target = target;
    }

    public IReadOnlyList<string> ColumnNames { get; }
    public double[][] Rows { get; }
    public int[] Target { get; }

    public int RowCount => Rows.Length;
    public int ColumnCount => ColumnNames.Count;
    public double DefaultRate => Target.Length == 0 ? 0d : Target.Average();
}
