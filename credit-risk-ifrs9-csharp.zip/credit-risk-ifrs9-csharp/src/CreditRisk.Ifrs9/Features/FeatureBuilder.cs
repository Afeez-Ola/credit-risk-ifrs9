using CreditRisk.Ifrs9.Configuration;
using CreditRisk.Ifrs9.Domain;
using CreditRisk.Ifrs9.Exceptions;

namespace CreditRisk.Ifrs9.Features;

/// <summary>
/// Turns loan records into a numeric design matrix: one-hot encoding for categoricals
/// and z-score standardisation for numerics. The encoding is fitted on the training
/// set only and then reused, so no test-set information reaches the model.
/// </summary>
public sealed class FeatureBuilder
{
    private readonly PipelineConfig _config;
    private List<string> _columns = new();
    private double[] _means = Array.Empty<double>();
    private double[] _standardDeviations = Array.Empty<double>();
    private IReadOnlyList<string> _grades = Array.Empty<string>();
    private IReadOnlyList<string> _purposes = Array.Empty<string>();

    public FeatureBuilder(PipelineConfig config) => _config = config;

    public bool IsFitted { get; private set; }

    public IReadOnlyList<string> ColumnNames => _columns;

    public FeatureMatrix FitTransform(IReadOnlyList<LoanRecord> loans)
    {
        if (loans.Count == 0)
            throw new DataValidationException("Cannot fit the encoder on an empty training set.");

        // Categorical levels are taken from training data; the first level of each is
        // dropped as the reference category to avoid perfect collinearity.
        _grades = loans.Select(l => l.Grade).Distinct().OrderBy(g => g).ToList();
        _purposes = loans.Select(l => l.Purpose).Distinct().OrderBy(p => p).ToList();

        _columns = BuildColumnNames();

        var raw = loans.Select(BuildRawRow).ToArray();
        var numericCount = NumericColumnCount;

        _means = new double[numericCount];
        _standardDeviations = new double[numericCount];

        for (var j = 0; j < numericCount; j++)
        {
            var column = raw.Select(r => r[j]).ToArray();
            _means[j] = column.Average();
            var variance = column.Sum(v => Math.Pow(v - _means[j], 2)) / Math.Max(1, column.Length - 1);
            _standardDeviations[j] = Math.Sqrt(variance);
            if (_standardDeviations[j] < 1e-12) _standardDeviations[j] = 1.0;
        }

        IsFitted = true;
        return Standardise(raw, loans);
    }

    public FeatureMatrix Transform(IReadOnlyList<LoanRecord> loans)
    {
        if (!IsFitted)
            throw new PipelineException("FeatureBuilder.Transform called before FitTransform.");

        return Standardise(loans.Select(BuildRawRow).ToArray(), loans);
    }

    private FeatureMatrix Standardise(double[][] raw, IReadOnlyList<LoanRecord> loans)
    {
        var numericCount = NumericColumnCount;

        foreach (var row in raw)
        {
            for (var j = 0; j < numericCount; j++)
                row[j] = (row[j] - _means[j]) / _standardDeviations[j];
        }

        var target = loans.Select(l => l.DefaultFlag
            ?? throw new DataValidationException($"Loan {l.Id} is unresolved and cannot be used for fitting."))
            .ToArray();

        return new FeatureMatrix(_columns, raw, target);
    }

    private int NumericColumnCount => 6;

    private List<string> BuildColumnNames()
    {
        var names = new List<string>
        {
            "loan_amnt", "int_rate", "annual_inc", "dti", "delinq_2yrs", "term"
        };

        names.AddRange(_grades.Skip(1).Select(g => $"grade_{g}"));
        names.AddRange(_purposes.Skip(1).Select(p => $"purpose_{p}"));
        return names;
    }

    private double[] BuildRawRow(LoanRecord loan)
    {
        var row = new double[_columns.Count];

        row[0] = (double)loan.LoanAmount;
        row[1] = loan.InterestRate;
        row[2] = loan.AnnualIncome;
        row[3] = loan.DebtToIncome;
        row[4] = loan.DelinquenciesLast2Years;
        row[5] = loan.TermMonths;

        var offset = NumericColumnCount;
        for (var i = 1; i < _grades.Count; i++)
            row[offset + i - 1] = loan.Grade == _grades[i] ? 1d : 0d;

        offset += Math.Max(0, _grades.Count - 1);
        for (var i = 1; i < _purposes.Count; i++)
            row[offset + i - 1] = loan.Purpose == _purposes[i] ? 1d : 0d;

        return row;
    }
}
