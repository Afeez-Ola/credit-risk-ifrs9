namespace CreditRisk.Ifrs9.Exceptions;

/// <summary>Base type for every error raised by the pipeline.</summary>
public class PipelineException : Exception
{
    public PipelineException(string message) : base(message) { }
    public PipelineException(string message, Exception inner) : base(message, inner) { }
}

/// <summary>Raised when input data is missing, malformed, or fails a sanity check.</summary>
public sealed class DataValidationException : PipelineException
{
    public DataValidationException(string message) : base(message) { }
    public DataValidationException(string message, Exception inner) : base(message, inner) { }
}

/// <summary>Raised when a model is used before it has been fitted.</summary>
public sealed class ModelNotTrainedException : PipelineException
{
    public ModelNotTrainedException(string modelName)
        : base($"Model '{modelName}' must be trained before it can score loans.") { }
}
