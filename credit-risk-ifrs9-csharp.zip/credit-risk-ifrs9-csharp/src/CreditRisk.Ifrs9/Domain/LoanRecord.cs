namespace CreditRisk.Ifrs9.Domain;

/// <summary>
/// A single loan as it exists in the source data. Only fields available at
/// origination are used as model inputs; see <see cref="Configuration.PipelineConfig.LeakageColumns"/>.
/// </summary>
public sealed class LoanRecord
{
    public required string Id { get; init; }
    public required DateOnly IssueDate { get; init; }
    public required string Status { get; init; }

    // At-origination attributes (permitted model inputs).
    public required string Grade { get; init; }
    public required string Purpose { get; init; }
    public required int TermMonths { get; init; }
    public decimal LoanAmount { get; init; }
    public double InterestRate { get; init; }
    public double AnnualIncome { get; init; }
    public double DebtToIncome { get; init; }
    public int DelinquenciesLast2Years { get; init; }

    // Post-origination behaviour. Excluded from features, used for staging only.
    public int DaysPastDue { get; init; }
    public decimal OutstandingBalance { get; init; }

    /// <summary>
    /// Resolved outcome: 1 = charged off, 0 = fully paid. Null while unresolved.
    /// </summary>
    public int? DefaultFlag => Status switch
    {
        "Charged Off" => 1,
        "Fully Paid" => 0,
        _ => null
    };

    public bool IsResolved => DefaultFlag.HasValue;
}
