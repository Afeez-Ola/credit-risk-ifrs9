namespace CreditRisk.Ifrs9.Domain;

/// <summary>A loan carrying its model output and assigned stage.</summary>
public sealed class ScoredLoan
{
    public required LoanRecord Loan { get; init; }

    /// <summary>Probability of default over the next 12 months.</summary>
    public required double Pd12Month { get; init; }

    /// <summary>Probability of default over the remaining life of the exposure.</summary>
    public required double PdLifetime { get; init; }

    /// <summary>PD estimated at origination, used for the SICR comparison.</summary>
    public required double PdAtOrigination { get; init; }

    public Ifrs9Stage Stage { get; set; } = Ifrs9Stage.Stage1;

    public int ActualDefault => Loan.DefaultFlag
        ?? throw new InvalidOperationException($"Loan {Loan.Id} is unresolved and has no outcome.");
}
