namespace CreditRisk.Ifrs9.Domain;

/// <summary>IFRS 9 impairment stages.</summary>
public enum Ifrs9Stage
{
    /// <summary>Performing. 12-month expected credit loss.</summary>
    Stage1 = 1,

    /// <summary>Significant increase in credit risk since origination. Lifetime ECL.</summary>
    Stage2 = 2,

    /// <summary>Credit impaired. Lifetime ECL.</summary>
    Stage3 = 3
}
