namespace CreditRisk.Ifrs9.Domain;

/// <summary>ECL for a single exposure: ECL = PD x LGD x EAD.</summary>
public sealed record EclResult(
    string LoanId,
    Ifrs9Stage Stage,
    double Pd,
    double Lgd,
    decimal Ead,
    decimal Ecl)
{
    /// <summary>ECL as a share of exposure.</summary>
    public double Coverage => Ead == 0m ? 0d : (double)(Ecl / Ead);
}

/// <summary>Portfolio ECL aggregated by stage, mirroring reports/ecl_summary.csv.</summary>
public sealed record StageSummary(
    Ifrs9Stage Stage,
    int LoanCount,
    decimal TotalExposure,
    decimal TotalEcl)
{
    public double CoverageRatio => TotalExposure == 0m ? 0d : (double)(TotalEcl / TotalExposure);
}
