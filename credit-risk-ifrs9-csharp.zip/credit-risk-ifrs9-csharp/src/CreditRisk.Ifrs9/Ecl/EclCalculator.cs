using CreditRisk.Ifrs9.Configuration;
using CreditRisk.Ifrs9.Domain;

namespace CreditRisk.Ifrs9.Ecl;

/// <summary>
/// Computes ECL = PD x LGD x EAD, discounted to present value. Stage 1 uses the
/// 12-month PD; stages 2 and 3 use lifetime PD, per IFRS 9.
/// </summary>
public sealed class EclCalculator
{
    private readonly PipelineConfig _config;

    public EclCalculator(PipelineConfig config) => _config = config;

    public EclResult Calculate(ScoredLoan scored)
    {
        ArgumentNullException.ThrowIfNull(scored);

        var pd = scored.Stage == Ifrs9Stage.Stage1 ? scored.Pd12Month : scored.PdLifetime;
        if (scored.Stage == Ifrs9Stage.Stage3) pd = 1.0; // already defaulted

        var ead = scored.Loan.OutstandingBalance * (decimal)_config.CreditConversionFactor;
        var horizonYears = scored.Stage == Ifrs9Stage.Stage1
            ? 1.0
            : Math.Max(1.0, scored.Loan.TermMonths / 12.0);

        var discount = 1.0 / Math.Pow(1.0 + _config.DiscountRate, horizonYears);
        var ecl = (decimal)(pd * _config.LossGivenDefault * discount) * ead;

        return new EclResult(
            LoanId: scored.Loan.Id,
            Stage: scored.Stage,
            Pd: pd,
            Lgd: _config.LossGivenDefault,
            Ead: decimal.Round(ead, 2),
            Ecl: decimal.Round(ecl, 2));
    }

    public IReadOnlyList<EclResult> CalculateAll(IEnumerable<ScoredLoan> loans)
        => loans.Select(Calculate).ToList();

    /// <summary>Aggregates exposure and ECL by stage, as reports/ecl_summary.csv does.</summary>
    public static IReadOnlyList<StageSummary> Summarise(IEnumerable<EclResult> results)
        => results
            .GroupBy(r => r.Stage)
            .OrderBy(g => g.Key)
            .Select(g => new StageSummary(
                Stage: g.Key,
                LoanCount: g.Count(),
                TotalExposure: g.Sum(r => r.Ead),
                TotalEcl: g.Sum(r => r.Ecl)))
            .ToList();
}
