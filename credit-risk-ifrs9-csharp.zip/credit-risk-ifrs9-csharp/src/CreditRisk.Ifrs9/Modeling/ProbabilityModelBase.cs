using CreditRisk.Ifrs9.Exceptions;
using CreditRisk.Ifrs9.Features;

namespace CreditRisk.Ifrs9.Modeling;

/// <summary>
/// Shared behaviour for probability models: the trained-state guard, batch scoring,
/// and the logistic link. Concrete models supply only the fitting routine and the
/// raw score for a single row.
/// </summary>
public abstract class ProbabilityModelBase : IProbabilityModel
{
    public abstract string Name { get; }

    public bool IsTrained { get; protected set; }

    public void Fit(FeatureMatrix training)
    {
        ArgumentNullException.ThrowIfNull(training);

        if (training.RowCount == 0)
            throw new DataValidationException("Training set is empty.");

        if (training.Target.Distinct().Count() < 2)
            throw new DataValidationException("Training target contains a single class; cannot fit.");

        FitCore(training);
        IsTrained = true;
    }

    public double PredictOne(double[] features)
    {
        EnsureTrained();
        ArgumentNullException.ThrowIfNull(features);
        return PredictCore(features);
    }

    public double[] Predict(FeatureMatrix data)
    {
        EnsureTrained();
        ArgumentNullException.ThrowIfNull(data);

        var predictions = new double[data.RowCount];
        for (var i = 0; i < data.RowCount; i++)
            predictions[i] = PredictCore(data.Rows[i]);

        return predictions;
    }

    protected abstract void FitCore(FeatureMatrix training);

    protected abstract double PredictCore(double[] features);

    protected static double Sigmoid(double z) => 1.0 / (1.0 + Math.Exp(-z));

    protected void EnsureTrained()
    {
        if (!IsTrained) throw new ModelNotTrainedException(Name);
    }
}
