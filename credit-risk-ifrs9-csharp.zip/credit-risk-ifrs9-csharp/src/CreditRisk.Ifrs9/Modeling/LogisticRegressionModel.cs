using CreditRisk.Ifrs9.Features;

namespace CreditRisk.Ifrs9.Modeling;

/// <summary>
/// The champion PD model: logistic regression fitted by batch gradient descent with
/// L2 regularisation. Kept as the primary model because it is interpretable and the
/// challenger's lift was marginal, which pointed to a data ceiling rather than a
/// modelling one.
/// </summary>
public sealed class LogisticRegressionModel : ProbabilityModelBase
{
    private readonly int _iterations;
    private readonly double _learningRate;
    private readonly double _l2;

    private double[] _weights = Array.Empty<double>();
    private double _intercept;

    public LogisticRegressionModel(int iterations = 600, double learningRate = 0.35, double l2 = 1e-4)
    {
        if (iterations <= 0) throw new ArgumentOutOfRangeException(nameof(iterations));
        if (learningRate <= 0) throw new ArgumentOutOfRangeException(nameof(learningRate));

        _iterations = iterations;
        _learningRate = learningRate;
        _l2 = l2;
    }

    public override string Name => "Logistic regression (champion)";

    /// <summary>Fitted coefficients, exposed for the interpretability the model is chosen for.</summary>
    public IReadOnlyDictionary<string, double> Coefficients { get; private set; } =
        new Dictionary<string, double>();

    protected override void FitCore(FeatureMatrix training)
    {
        var rows = training.Rows;
        var target = training.Target;
        var n = training.RowCount;
        var p = training.ColumnCount;

        _weights = new double[p];
        _intercept = 0d;

        for (var iteration = 0; iteration < _iterations; iteration++)
        {
            var gradient = new double[p];
            var interceptGradient = 0d;

            for (var i = 0; i < n; i++)
            {
                var error = Sigmoid(Score(rows[i])) - target[i];
                interceptGradient += error;

                var row = rows[i];
                for (var j = 0; j < p; j++)
                    gradient[j] += error * row[j];
            }

            _intercept -= _learningRate * interceptGradient / n;

            for (var j = 0; j < p; j++)
                _weights[j] -= _learningRate * (gradient[j] / n + _l2 * _weights[j]);
        }

        Coefficients = training.ColumnNames
            .Select((name, j) => (name, weight: _weights[j]))
            .ToDictionary(x => x.name, x => x.weight);
    }

    protected override double PredictCore(double[] features) => Sigmoid(Score(features));

    private double Score(IReadOnlyList<double> features)
    {
        var z = _intercept;
        for (var j = 0; j < _weights.Length; j++)
            z += _weights[j] * features[j];
        return z;
    }
}
