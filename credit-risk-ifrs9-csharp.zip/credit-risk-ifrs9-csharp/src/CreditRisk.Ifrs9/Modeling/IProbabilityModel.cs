using CreditRisk.Ifrs9.Features;

namespace CreditRisk.Ifrs9.Modeling;

/// <summary>
/// A binary probability model. Champion and challenger models implement this so the
/// pipeline can swap them without changing any downstream stage.
/// </summary>
public interface IProbabilityModel
{
    string Name { get; }
    bool IsTrained { get; }

    void Fit(FeatureMatrix training);
    double PredictOne(double[] features);
    double[] Predict(FeatureMatrix data);
}
