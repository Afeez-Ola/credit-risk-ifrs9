using CreditRisk.Ifrs9.Domain;

namespace CreditRisk.Ifrs9.Data;

/// <summary>Source of loan records. Implementations may read CSV, a database, or generate data.</summary>
public interface ILoanRepository
{
    IReadOnlyList<LoanRecord> GetLoans();
}
