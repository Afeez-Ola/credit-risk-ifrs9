using CreditRisk.Ifrs9.Domain;

namespace CreditRisk.Ifrs9.Data;

/// <summary>
/// Generates a reproducible synthetic book so the pipeline runs end to end without
/// the Kaggle download. Default risk is driven by grade, rate, DTI and delinquency
/// history, so a well specified model should recover a real signal.
/// </summary>
public sealed class SyntheticLoanGenerator : ILoanRepository
{
    private static readonly string[] Grades = { "A", "B", "C", "D", "E", "F", "G" };
    private static readonly double[] GradeRisk = { -2.6, -2.1, -1.7, -1.3, -0.9, -0.5, -0.1 };

    private static readonly string[] Purposes =
    {
        "debt_consolidation", "credit_card", "home_improvement", "major_purchase", "small_business"
    };

    private readonly int _count;
    private readonly Random _random;

    public SyntheticLoanGenerator(int count = 40_000, int seed = 42)
    {
        if (count <= 0) throw new ArgumentOutOfRangeException(nameof(count));
        _count = count;
        _random = new Random(seed);
    }

    public IReadOnlyList<LoanRecord> GetLoans()
    {
        var loans = new List<LoanRecord>(_count);

        for (var i = 0; i < _count; i++)
        {
            var gradeIx = WeightedGrade();
            var grade = Grades[gradeIx];
            var term = _random.NextDouble() < 0.75 ? 36 : 60;
            var rate = 5.5 + gradeIx * 3.1 + _random.NextDouble() * 2.0;
            var income = 30_000 + _random.NextDouble() * 90_000;
            var dti = 4 + _random.NextDouble() * 30;
            var delinquencies = _random.NextDouble() < 0.18 ? _random.Next(1, 4) : 0;
            var amount = 2_000 + _random.NextDouble() * 33_000;

            // Vintages spread over six years; later books deteriorate slightly,
            // which is what makes out-of-time validation meaningful.
            var issue = new DateOnly(2013, 1, 1).AddDays(_random.Next(0, 365 * 6));
            var vintageDrift = issue >= new DateOnly(2016, 10, 1) ? 0.22 : 0.0;

            var logit = GradeRisk[gradeIx]
                        + 0.030 * (rate - 12.0)
                        + 0.022 * (dti - 18.0)
                        + 0.240 * delinquencies
                        + (term == 60 ? 0.35 : 0.0)
                        - 0.0000045 * (income - 60_000)
                        + vintageDrift
                        + NextGaussian() * 0.45;

            var defaulted = _random.NextDouble() < 1.0 / (1.0 + Math.Exp(-logit));
            var balance = (decimal)(amount * (0.35 + _random.NextDouble() * 0.6));

            loans.Add(new LoanRecord
            {
                Id = $"L{i:D7}",
                IssueDate = issue,
                Status = defaulted ? "Charged Off" : "Fully Paid",
                Grade = grade,
                Purpose = Purposes[_random.Next(Purposes.Length)],
                TermMonths = term,
                LoanAmount = (decimal)Math.Round(amount, 2),
                InterestRate = Math.Round(rate, 2),
                AnnualIncome = Math.Round(income, 2),
                DebtToIncome = Math.Round(dti, 2),
                DelinquenciesLast2Years = delinquencies,
                DaysPastDue = defaulted ? DrawDelinquentDpd() : DrawPerformingDpd(),
                OutstandingBalance = decimal.Round(balance, 2)
            });
        }

        return loans;
    }

    private int WeightedGrade()
    {
        // Skewed towards better grades, as a real consumer book is.
        double[] weights = { 0.17, 0.28, 0.26, 0.15, 0.08, 0.04, 0.02 };
        var draw = _random.NextDouble();
        var cumulative = 0.0;

        for (var i = 0; i < weights.Length; i++)
        {
            cumulative += weights[i];
            if (draw <= cumulative) return i;
        }

        return weights.Length - 1;
    }

    private int DrawDelinquentDpd()
    {
        var draw = _random.NextDouble();
        if (draw < 0.55) return 90 + _random.Next(0, 120);
        if (draw < 0.80) return 30 + _random.Next(0, 60);
        return _random.Next(0, 30);
    }

    private int DrawPerformingDpd() => _random.NextDouble() < 0.04 ? _random.Next(1, 45) : 0;

    private double NextGaussian()
    {
        var u1 = 1.0 - _random.NextDouble();
        var u2 = 1.0 - _random.NextDouble();
        return Math.Sqrt(-2.0 * Math.Log(u1)) * Math.Sin(2.0 * Math.PI * u2);
    }
}
