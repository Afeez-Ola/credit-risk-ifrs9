using System.Globalization;
using CreditRisk.Ifrs9.Domain;
using CreditRisk.Ifrs9.Exceptions;

namespace CreditRisk.Ifrs9.Data;

/// <summary>
/// Reads loans from the Lending Club style CSV. Parsing is deliberately defensive:
/// a malformed row is reported with its line number rather than silently dropped.
/// </summary>
public sealed class CsvLoanRepository : ILoanRepository
{
    private readonly string _path;

    public CsvLoanRepository(string path)
    {
        if (string.IsNullOrWhiteSpace(path))
            throw new ArgumentException("Path must not be empty.", nameof(path));
        _path = path;
    }

    public IReadOnlyList<LoanRecord> GetLoans()
    {
        if (!File.Exists(_path))
            throw new DataValidationException($"Source file not found: {_path}");

        var loans = new List<LoanRecord>();
        using var reader = new StreamReader(_path);

        var headerLine = reader.ReadLine()
            ?? throw new DataValidationException($"File '{_path}' is empty.");
        var header = SplitCsvLine(headerLine);
        var index = BuildIndex(header);

        var lineNumber = 1;
        while (reader.ReadLine() is { } line)
        {
            lineNumber++;
            if (string.IsNullOrWhiteSpace(line)) continue;

            try
            {
                loans.Add(ParseRow(SplitCsvLine(line), index));
            }
            catch (Exception ex) when (ex is FormatException or IndexOutOfRangeException)
            {
                throw new DataValidationException(
                    $"Malformed row at line {lineNumber} of '{_path}'.", ex);
            }
        }

        if (loans.Count == 0)
            throw new DataValidationException($"No loan rows parsed from '{_path}'.");

        return loans;
    }

    private static Dictionary<string, int> BuildIndex(IReadOnlyList<string> header)
    {
        var index = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
        for (var i = 0; i < header.Count; i++)
            index[header[i].Trim()] = i;

        foreach (var required in new[] { "id", "issue_d", "loan_status", "grade", "loan_amnt" })
        {
            if (!index.ContainsKey(required))
                throw new DataValidationException($"Required column '{required}' missing from header.");
        }

        return index;
    }

    private static LoanRecord ParseRow(IReadOnlyList<string> row, IReadOnlyDictionary<string, int> ix)
    {
        string Text(string col) => ix.TryGetValue(col, out var i) && i < row.Count ? row[i].Trim() : string.Empty;

        double Number(string col, double fallback = 0d)
        {
            var raw = Text(col).Replace("%", string.Empty).Replace("months", string.Empty).Trim();
            return double.TryParse(raw, NumberStyles.Any, CultureInfo.InvariantCulture, out var v) ? v : fallback;
        }

        return new LoanRecord
        {
            Id = Text("id"),
            IssueDate = ParseIssueDate(Text("issue_d")),
            Status = Text("loan_status"),
            Grade = Text("grade"),
            Purpose = Text("purpose"),
            TermMonths = (int)Number("term", 36),
            LoanAmount = (decimal)Number("loan_amnt"),
            InterestRate = Number("int_rate"),
            AnnualIncome = Number("annual_inc"),
            DebtToIncome = Number("dti"),
            DelinquenciesLast2Years = (int)Number("delinq_2yrs"),
            DaysPastDue = (int)Number("days_past_due"),
            OutstandingBalance = (decimal)Number("outstanding_balance")
        };
    }

    /// <summary>Lending Club writes issue dates as "Dec-2015"; ISO dates are accepted too.</summary>
    private static DateOnly ParseIssueDate(string raw)
    {
        if (string.IsNullOrWhiteSpace(raw))
            throw new FormatException("Empty issue date.");

        string[] formats = { "MMM-yyyy", "MMM-yy", "yyyy-MM-dd", "yyyy-MM" };
        if (DateOnly.TryParseExact(raw, formats, CultureInfo.InvariantCulture,
                DateTimeStyles.None, out var parsed))
            return parsed;

        if (DateOnly.TryParse(raw, CultureInfo.InvariantCulture, DateTimeStyles.None, out parsed))
            return parsed;

        throw new FormatException($"Unrecognised issue date '{raw}'.");
    }

    /// <summary>Minimal CSV splitter honouring quoted fields.</summary>
    private static List<string> SplitCsvLine(string line)
    {
        var fields = new List<string>();
        var current = new System.Text.StringBuilder();
        var inQuotes = false;

        foreach (var ch in line)
        {
            if (ch == '"') inQuotes = !inQuotes;
            else if (ch == ',' && !inQuotes)
            {
                fields.Add(current.ToString());
                current.Clear();
            }
            else current.Append(ch);
        }

        fields.Add(current.ToString());
        return fields;
    }
}
