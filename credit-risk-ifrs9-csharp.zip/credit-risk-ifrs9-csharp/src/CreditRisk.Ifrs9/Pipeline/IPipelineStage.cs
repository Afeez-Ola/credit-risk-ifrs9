namespace CreditRisk.Ifrs9.Pipeline;

/// <summary>One step of the pipeline. Stages run in order, each consuming the previous one's output.</summary>
public interface IPipelineStage
{
    string Name { get; }
    void Execute(PipelineContext context);
}
