using CreditRisk.Ifrs9.Data;
using CreditRisk.Ifrs9.Domain;
using CreditRisk.Ifrs9.Ecl;
using CreditRisk.Ifrs9.Exceptions;
using CreditRisk.Ifrs9.Features;
using CreditRisk.Ifrs9.Modeling;
using CreditRisk.Ifrs9.Staging;
using CreditRisk.Ifrs9.Validation;

namespace CreditRisk.Ifrs9.Pipeline;

/// <summary>Stage 01: load the source book and keep resolved loans only.</summary>
public sealed class BuildDatasetStage : PipelineStageBase
{
    private readonly ILoanRepository _repository;

    public BuildDatasetStage(ILoanRepository repository) => _repository = repository;

    public override string Name => "01 build_dataset";

    protected override void ExecuteCore(PipelineContext context)
    {
        var loans = _repository.GetLoans();
        Report($"loaded {loans.Count:N0} rows");

        var resolved = loans
            .Where(l => context.Config.ResolvedStatuses.Contains(l.Status))
            .Where(l => l.IsResolved)
            .ToList();

        if (resolved.Count == 0)
            throw new DataValidationException("No resolved loans (Fully Paid / Charged Off) found.");

        context.RawLoans = loans;
        context.ModelTable = resolved;

        Report($"kept {resolved.Count:N0} resolved loans, default rate {resolved.Average(l => l.DefaultFlag!.Value):P2}");
    }
}

/// <summary>Stage 02: build the model table and split out of time.</summary>
public sealed class CleanFeaturesStage : PipelineStageBase
{
    public override string Name => "02 clean_features";

    protected override void ExecuteCore(PipelineContext context)
    {
        var split = context.Config.OutOfTimeSplit;

        var train = context.ModelTable.Where(l => l.IssueDate < split).ToList();
        var test = context.ModelTable.Where(l => l.IssueDate >= split).ToList();

        if (train.Count == 0 || test.Count == 0)
            throw new DataValidationException(
                $"Out-of-time split at {split:yyyy-MM} left an empty side (train {train.Count}, test {test.Count}).");

        var builder = new FeatureBuilder(context.Config);
        context.TrainMatrix = builder.FitTransform(train);
        context.TestMatrix = builder.Transform(test);

        context.FeatureBuilder = builder;
        context.TrainLoans = train;
        context.TestLoans = test;

        Report($"train {train.Count:N0} loans (< {split:yyyy-MM}), test {test.Count:N0} loans (>= {split:yyyy-MM})");
        Report($"{builder.ColumnNames.Count} features; leakage columns excluded: {context.Config.LeakageColumns.Count}");
    }
}

/// <summary>Stage 03: fit the PD model and measure discrimination out of time.</summary>
public sealed class TrainPdStage : PipelineStageBase
{
    private readonly IProbabilityModel _model;

    public TrainPdStage(IProbabilityModel model) => _model = model;

    public override string Name => "03 train_pd";

    protected override void ExecuteCore(PipelineContext context)
    {
        var train = context.TrainMatrix ?? throw new PipelineException("Train matrix missing.");
        var test = context.TestMatrix ?? throw new PipelineException("Test matrix missing.");

        _model.Fit(train);

        context.Model = _model;
        context.TrainScores = _model.Predict(train);
        context.TestScores = _model.Predict(test);

        var auc = ValidationMetrics.AreaUnderCurve(context.TestScores, test.Target);
        var gini = ValidationMetrics.Gini(context.TestScores, test.Target);
        var ks = ValidationMetrics.KolmogorovSmirnov(context.TestScores, test.Target);

        context.Metrics["oot_auc"] = auc;
        context.Metrics["oot_gini"] = gini;
        context.Metrics["oot_ks"] = ks;

        Report($"{_model.Name}: OOT AUC {auc:F4}, Gini {gini:F4}, KS {ks:F4}");
    }
}

/// <summary>Stage 04: assign IFRS 9 stages using the SICR policy.</summary>
public sealed class StagingStage : PipelineStageBase
{
    private readonly ISicrPolicy _policy;

    public StagingStage(ISicrPolicy policy) => _policy = policy;

    public override string Name => "04 staging";

    protected override void ExecuteCore(PipelineContext context)
    {
        var model = context.Model ?? throw new PipelineException("Model missing.");
        var test = context.TestMatrix ?? throw new PipelineException("Test matrix missing.");

        // The SICR test must compare like with like: a lifetime PD today against the
        // lifetime PD expected at origination. Comparing a lifetime figure against a
        // 12-month one would push essentially the whole book into Stage 2.
        const double originationOddsHaircut = 0.85;

        for (var i = 0; i < context.TestLoans.Count; i++)
        {
            var loan = context.TestLoans[i];
            var pd12 = context.TestScores[i];
            var years = Math.Max(1.0, loan.TermMonths / 12.0);
            var pdLifetime = 1.0 - Math.Pow(1.0 - pd12, years);

            // Origination view: the same exposure before any deterioration.
            var pd12AtOrigination = model.PredictOne(test.Rows[i]) * originationOddsHaircut;
            var pdAtOrigination = 1.0 - Math.Pow(1.0 - pd12AtOrigination, years);

            var scored = new ScoredLoan
            {
                Loan = loan,
                Pd12Month = pd12,
                PdLifetime = pdLifetime,
                PdAtOrigination = pdAtOrigination
            };

            scored.Stage = _policy.Assign(scored);
            context.ScoredLoans.Add(scored);
        }

        foreach (var group in context.ScoredLoans.GroupBy(s => s.Stage).OrderBy(g => g.Key))
            Report($"{group.Key}: {group.Count():N0} loans");
    }
}

/// <summary>Stage 05: apply LGD and EAD assumptions and compute ECL.</summary>
public sealed class EclStage : PipelineStageBase
{
    private readonly EclCalculator _calculator;

    public EclStage(EclCalculator calculator) => _calculator = calculator;

    public override string Name => "05 ecl";

    protected override void ExecuteCore(PipelineContext context)
    {
        if (context.ScoredLoans.Count == 0)
            throw new PipelineException("No scored loans available for ECL computation.");

        context.EclResults.AddRange(_calculator.CalculateAll(context.ScoredLoans));
        context.StageSummaries = EclCalculator.Summarise(context.EclResults);

        foreach (var summary in context.StageSummaries)
        {
            Report($"{summary.Stage}: {summary.LoanCount:N0} loans, " +
                   $"exposure {summary.TotalExposure:N0}, ECL {summary.TotalEcl:N0}, " +
                   $"coverage {summary.CoverageRatio:P1}");
        }
    }
}

/// <summary>Stage 06: discrimination, calibration and stability checks.</summary>
public sealed class ValidationStage : PipelineStageBase
{
    public override string Name => "06 validation";

    protected override void ExecuteCore(PipelineContext context)
    {
        var test = context.TestMatrix ?? throw new PipelineException("Test matrix missing.");

        var psi = ValidationMetrics.PopulationStabilityIndex(context.TrainScores, context.TestScores);
        context.Metrics["score_psi"] = psi;

        var verdict = psi switch
        {
            < 0.10 => "stable",
            < 0.25 => "monitor",
            _ => "shifted"
        };

        Report($"score PSI (train -> test): {psi:F4} ({verdict})");

        var calibration = ValidationMetrics.CalibrationTable(context.TestScores, test.Target);
        Report("decile  n       predicted  observed   diff");

        foreach (var bin in calibration)
        {
            Report($"{bin.Decile,6}  {bin.Count,-6:N0}  {bin.MeanPredicted,9:F4}  " +
                   $"{bin.ObservedRate,8:F4}  {bin.Difference,+7:F4}");
        }

        var underPredicted = calibration.Count(b => b.Difference > 0.01);
        if (underPredicted > 0)
        {
            Report($"{underPredicted} decile(s) under-predict by more than 1pp; " +
                   "recalibration with a margin of conservatism is indicated.");
        }
    }
}
