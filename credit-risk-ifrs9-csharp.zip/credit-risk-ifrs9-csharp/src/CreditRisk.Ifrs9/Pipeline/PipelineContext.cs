using CreditRisk.Ifrs9.Configuration;
using CreditRisk.Ifrs9.Domain;
using CreditRisk.Ifrs9.Features;
using CreditRisk.Ifrs9.Modeling;

namespace CreditRisk.Ifrs9.Pipeline;

/// <summary>
/// State handed from one stage to the next, the equivalent of each script writing a
/// file the next one reads.
/// </summary>
public sealed class PipelineContext
{
    public PipelineContext(PipelineConfig config) => Config = config;

    public PipelineConfig Config { get; }

    public IReadOnlyList<LoanRecord> RawLoans { get; set; } = Array.Empty<LoanRecord>();
    public IReadOnlyList<LoanRecord> ModelTable { get; set; } = Array.Empty<LoanRecord>();
    public IReadOnlyList<LoanRecord> TrainLoans { get; set; } = Array.Empty<LoanRecord>();
    public IReadOnlyList<LoanRecord> TestLoans { get; set; } = Array.Empty<LoanRecord>();

    public FeatureBuilder? FeatureBuilder { get; set; }
    public FeatureMatrix? TrainMatrix { get; set; }
    public FeatureMatrix? TestMatrix { get; set; }

    public IProbabilityModel? Model { get; set; }
    public double[] TrainScores { get; set; } = Array.Empty<double>();
    public double[] TestScores { get; set; } = Array.Empty<double>();

    public List<ScoredLoan> ScoredLoans { get; } = new();
    public List<EclResult> EclResults { get; } = new();
    public IReadOnlyList<StageSummary> StageSummaries { get; set; } = Array.Empty<StageSummary>();

    public Dictionary<string, double> Metrics { get; } = new();
}
