using System.Diagnostics;
using CreditRisk.Ifrs9.Exceptions;

namespace CreditRisk.Ifrs9.Pipeline;

/// <summary>
/// Handles the concerns every stage shares: console reporting, timing, and wrapping
/// unexpected failures with the name of the stage that raised them. Subclasses
/// implement only <see cref="ExecuteCore"/>.
/// </summary>
public abstract class PipelineStageBase : IPipelineStage
{
    public abstract string Name { get; }

    public void Execute(PipelineContext context)
    {
        ArgumentNullException.ThrowIfNull(context);

        Console.WriteLine($"[{Name}] starting");
        var stopwatch = Stopwatch.StartNew();

        try
        {
            ExecuteCore(context);
        }
        catch (PipelineException)
        {
            throw; // already descriptive
        }
        catch (Exception ex)
        {
            throw new PipelineException($"Stage '{Name}' failed: {ex.Message}", ex);
        }

        stopwatch.Stop();
        Console.WriteLine($"[{Name}] done in {stopwatch.ElapsedMilliseconds} ms");
    }

    protected abstract void ExecuteCore(PipelineContext context);

    protected static void Report(string message) => Console.WriteLine($"    {message}");
}
