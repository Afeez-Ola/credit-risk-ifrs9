using CreditRisk.Ifrs9.Configuration;

namespace CreditRisk.Ifrs9.Pipeline;

/// <summary>Runs the stages in order against a shared context.</summary>
public sealed class PipelineRunner
{
    private readonly IReadOnlyList<IPipelineStage> _stages;

    public PipelineRunner(IEnumerable<IPipelineStage> stages)
    {
        _stages = stages.ToList();
        if (_stages.Count == 0)
            throw new ArgumentException("At least one stage is required.", nameof(stages));
    }

    public PipelineContext Run(PipelineConfig config)
    {
        ArgumentNullException.ThrowIfNull(config);
        config.EnsureDirectories();

        var context = new PipelineContext(config);

        foreach (var stage in _stages)
            stage.Execute(context);

        return context;
    }
}
