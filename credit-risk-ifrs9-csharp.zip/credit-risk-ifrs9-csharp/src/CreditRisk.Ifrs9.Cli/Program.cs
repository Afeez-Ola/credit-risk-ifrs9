using CreditRisk.Ifrs9.Configuration;
using CreditRisk.Ifrs9.Data;
using CreditRisk.Ifrs9.Ecl;
using CreditRisk.Ifrs9.Exceptions;
using CreditRisk.Ifrs9.Modeling;
using CreditRisk.Ifrs9.Pipeline;
using CreditRisk.Ifrs9.Reporting;
using CreditRisk.Ifrs9.Staging;

namespace CreditRisk.Ifrs9.Cli;

/// <summary>
/// Entry point. Runs the full IFRS 9 pipeline against the Lending Club CSV when it
/// is present, otherwise against a reproducible synthetic book so the project runs
/// out of the box.
///
///   dotnet run --project src/CreditRisk.Ifrs9.Cli
///   dotnet run --project src/CreditRisk.Ifrs9.Cli -- --data data --rows 40000
/// </summary>
public static class Program
{
    public static int Main(string[] args)
    {
        try
        {
            var config = BuildConfig(args);
            var repository = ResolveRepository(config, args);

            var runner = new PipelineRunner(new IPipelineStage[]
            {
                new BuildDatasetStage(repository),
                new CleanFeaturesStage(),
                new TrainPdStage(new LogisticRegressionModel()),
                new StagingStage(new SicrPolicy(config)),
                new EclStage(new EclCalculator(config)),
                new ValidationStage()
            });

            Console.WriteLine("IFRS 9 expected credit loss pipeline");
            Console.WriteLine(new string('-', 60));

            var context = runner.Run(config);

            var writer = new CsvReportWriter(config.ReportsDirectory);
            writer.WriteEclSummary(context);
            writer.WriteMetrics(context);

            if (context.Model is LogisticRegressionModel champion)
                writer.WriteCoefficients(champion.Coefficients);

            Console.WriteLine(new string('-', 60));
            Console.WriteLine($"Reports written to '{config.ReportsDirectory}'.");
            return 0;
        }
        catch (DataValidationException ex)
        {
            Console.Error.WriteLine($"Data error: {ex.Message}");
            return 2;
        }
        catch (PipelineException ex)
        {
            Console.Error.WriteLine($"Pipeline error: {ex.Message}");
            return 1;
        }
    }

    private static PipelineConfig BuildConfig(string[] args) => new()
    {
        DataDirectory = ReadOption(args, "--data") ?? "data",
        ReportsDirectory = ReadOption(args, "--reports") ?? "reports"
    };

    private static ILoanRepository ResolveRepository(PipelineConfig config, string[] args)
    {
        if (File.Exists(config.SourcePath))
        {
            Console.WriteLine($"Source: {config.SourcePath}");
            return new CsvLoanRepository(config.SourcePath);
        }

        var rows = int.TryParse(ReadOption(args, "--rows"), out var parsed) ? parsed : 40_000;
        Console.WriteLine($"Source: synthetic book ({rows:N0} loans); place loan.csv in " +
                          $"'{config.DataDirectory}' to use the real dataset.");

        return new SyntheticLoanGenerator(rows);
    }

    private static string? ReadOption(string[] args, string name)
    {
        var index = Array.IndexOf(args, name);
        return index >= 0 && index + 1 < args.Length ? args[index + 1] : null;
    }
}
