# credit-risk-ifrs9 (C# / .NET 8)

End to end IFRS 9 expected credit loss model in C#: PD modelling, stage
allocation, LGD/EAD assumptions, ECL computation, and model validation.

This is a C# port of the original Python implementation
([credit-risk-ifrs9](https://github.com/Afeez-Ola/credit-risk-ifrs9)). The
methodology is unchanged; the point of the port is to express the same pipeline
in an object-oriented .NET codebase: interfaces for the swappable parts, an
abstract base class for shared stage behaviour, and typed domain models
throughout.

## Solution layout

```
src/CreditRisk.Ifrs9/            Class library
  Configuration/PipelineConfig   Paths, feature lists, leakage columns, thresholds
  Domain/                        LoanRecord, ScoredLoan, Ifrs9Stage, EclResult
  Data/                          ILoanRepository, CsvLoanRepository, SyntheticLoanGenerator
  Features/                      FeatureBuilder (one-hot + standardisation), FeatureMatrix
  Modeling/                      IProbabilityModel, ProbabilityModelBase, LogisticRegressionModel
  Staging/                       ISicrPolicy, SicrPolicy
  Ecl/                           EclCalculator
  Validation/                    ValidationMetrics (AUC, Gini, KS, PSI, calibration)
  Pipeline/                      IPipelineStage, PipelineStageBase, six stages, PipelineRunner
  Reporting/                     CsvReportWriter
  Exceptions/                    PipelineException, DataValidationException, ModelNotTrainedException

src/CreditRisk.Ifrs9.Cli/        Console entry point
tests/CreditRisk.Ifrs9.Tests/    xunit suite
```

## Pipeline

The six stages mirror the numbered scripts of the Python version. Each consumes
the previous stage's output through a shared `PipelineContext`.

| Stage | Responsibility |
| --- | --- |
| `BuildDatasetStage` | Load the book, keep resolved loans (Fully Paid / Charged Off) |
| `CleanFeaturesStage` | Build the model table, split out of time, encode features |
| `TrainPdStage` | Fit the logistic regression PD model, measure AUC / Gini / KS |
| `StagingStage` | Assign IFRS 9 stages under the SICR policy |
| `EclStage` | Apply LGD and EAD assumptions, compute ECL = PD x LGD x EAD |
| `ValidationStage` | Discrimination, calibration by decile, PSI stability |

## Run

```bash
dotnet build
dotnet run --project src/CreditRisk.Ifrs9.Cli
```

With no `data/loan.csv` present the pipeline runs against a reproducible
synthetic book, so it works out of the box. Place the Kaggle Lending Club
`loan.csv` in `data/` to run on the real dataset:

```bash
dotnet run --project src/CreditRisk.Ifrs9.Cli -- --data data --reports reports
```

## Tests

```bash
dotnet test
```

24 tests cover the metric implementations against known edge cases (perfect
separation, inverted ranking, all-ties, single-class targets), the SICR rules,
the ECL arithmetic, encoder state guards, and the reproducibility of the
synthetic generator.

## Design notes

- **Leakage control.** Only at-origination information reaches the model.
  Payment, recovery, hardship and settlement fields are listed in
  `PipelineConfig.LeakageColumns` and never enter the feature matrix.
- **Encoder fitted on training data only.** `FeatureBuilder.FitTransform` learns
  the categorical levels and standardisation statistics; the test set goes
  through `Transform`, so no test information leaks into the fit.
- **Like-for-like SICR comparison.** The stage test compares a lifetime PD today
  against the lifetime PD at origination. Comparing a lifetime figure against a
  12-month one pushes essentially the whole book into Stage 2.
- **Interpretable champion.** Logistic regression is retained as the primary
  model and its coefficients are written to `reports/pd_coefficients.csv`. In the
  original study the gradient-boosted challenger added only marginal lift, which
  pointed to a ceiling in the at-origination information set rather than in model
  capacity.
- **Errors are typed.** Bad input raises `DataValidationException`; using a model
  before fitting raises `ModelNotTrainedException`; stage failures are wrapped in
  `PipelineException` naming the stage.

## Output

`reports/ecl_summary.csv`, `reports/model_metrics.csv`, and
`reports/pd_coefficients.csv`.

Indicative run on the synthetic book (30,000 loans):

| Metric | Value |
| --- | --- |
| Out-of-time AUC | 0.6964 |
| Gini | 0.3927 |
| KS | 0.3006 |
| Score PSI (train to test) | 0.0010 |

| Stage | Loans | Coverage |
| --- | --- | --- |
| Stage 1 | 4,303 | 7.4% |
| Stage 2 | 5,540 | 28.8% |
| Stage 3 | 1,450 | 49.5% |

## Stated limitations

- LGD and EAD are assumption based, not modelled from recovery data.
- The synthetic generator exists so the project runs without the Kaggle
  download; figures from it are illustrative, not a credit study.
- Macroeconomic scenario weighting is not implemented in this port.

## Author

Afeez Bolaji Olanrewaju, MSc Quantitative Asset and Risk Management,
University of Economics in Katowice.
