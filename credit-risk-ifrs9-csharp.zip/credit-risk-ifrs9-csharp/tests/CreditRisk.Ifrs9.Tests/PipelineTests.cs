using CreditRisk.Ifrs9.Configuration;
using CreditRisk.Ifrs9.Data;
using CreditRisk.Ifrs9.Domain;
using CreditRisk.Ifrs9.Ecl;
using CreditRisk.Ifrs9.Exceptions;
using CreditRisk.Ifrs9.Features;
using CreditRisk.Ifrs9.Modeling;
using CreditRisk.Ifrs9.Staging;
using CreditRisk.Ifrs9.Validation;
using Xunit;

namespace CreditRisk.Ifrs9.Tests;

public class ValidationMetricsTests
{
    [Fact]
    public void PerfectSeparationGivesAucOfOne()
    {
        var scores = new[] { 0.1, 0.2, 0.8, 0.9 };
        var labels = new[] { 0, 0, 1, 1 };

        Assert.Equal(1.0, ValidationMetrics.AreaUnderCurve(scores, labels), 6);
        Assert.Equal(1.0, ValidationMetrics.Gini(scores, labels), 6);
    }

    [Fact]
    public void InvertedRankingGivesAucOfZero()
    {
        var scores = new[] { 0.9, 0.8, 0.2, 0.1 };
        var labels = new[] { 0, 0, 1, 1 };

        Assert.Equal(0.0, ValidationMetrics.AreaUnderCurve(scores, labels), 6);
    }

    [Fact]
    public void TiedScoresGiveAucOfOneHalf()
    {
        var scores = new[] { 0.5, 0.5, 0.5, 0.5 };
        var labels = new[] { 0, 1, 0, 1 };

        Assert.Equal(0.5, ValidationMetrics.AreaUnderCurve(scores, labels), 6);
    }

    [Fact]
    public void AucRejectsSingleClassTarget()
    {
        var scores = new[] { 0.2, 0.4, 0.6 };
        var labels = new[] { 0, 0, 0 };

        Assert.Throws<DataValidationException>(() => ValidationMetrics.AreaUnderCurve(scores, labels));
    }

    [Fact]
    public void AucRejectsMismatchedLengths()
    {
        Assert.Throws<DataValidationException>(
            () => ValidationMetrics.AreaUnderCurve(new[] { 0.1, 0.2 }, new[] { 1 }));
    }

    [Fact]
    public void IdenticalDistributionsGiveNearZeroPsi()
    {
        var reference = Enumerable.Range(0, 1000).Select(i => i / 1000.0).ToArray();
        var psi = ValidationMetrics.PopulationStabilityIndex(reference, reference);

        Assert.True(psi < 0.01, $"Expected a near-zero PSI, got {psi:F4}.");
    }

    [Fact]
    public void ShiftedDistributionGivesLargePsi()
    {
        var reference = Enumerable.Range(0, 1000).Select(i => i / 1000.0).ToArray();
        var shifted = reference.Select(v => v * 0.25 + 0.75).ToArray();

        Assert.True(ValidationMetrics.PopulationStabilityIndex(reference, shifted) > 0.25);
    }

    [Fact]
    public void CalibrationTableCoversEveryObservation()
    {
        var random = new Random(7);
        var predictions = Enumerable.Range(0, 500).Select(_ => random.NextDouble()).ToArray();
        var labels = predictions.Select(p => random.NextDouble() < p ? 1 : 0).ToArray();

        var table = ValidationMetrics.CalibrationTable(predictions, labels);

        Assert.Equal(10, table.Count);
        Assert.Equal(predictions.Length, table.Sum(b => b.Count));
    }
}

public class LogisticRegressionModelTests
{
    [Fact]
    public void ScoringBeforeFittingThrows()
    {
        var model = new LogisticRegressionModel();
        Assert.Throws<ModelNotTrainedException>(() => model.PredictOne(new[] { 0.5, 0.5 }));
    }

    [Fact]
    public void FittingOnSingleClassThrows()
    {
        var matrix = new FeatureMatrix(
            new[] { "x" },
            new[] { new[] { 0.1 }, new[] { 0.2 } },
            new[] { 0, 0 });

        Assert.Throws<DataValidationException>(() => new LogisticRegressionModel().Fit(matrix));
    }

    [Fact]
    public void ModelLearnsASeparableSignal()
    {
        var rows = new List<double[]>();
        var target = new List<int>();

        for (var i = 0; i < 200; i++)
        {
            rows.Add(new[] { -1.0 + i * 0.001 });
            target.Add(0);
            rows.Add(new[] { 1.0 + i * 0.001 });
            target.Add(1);
        }

        var matrix = new FeatureMatrix(new[] { "x" }, rows.ToArray(), target.ToArray());
        var model = new LogisticRegressionModel();
        model.Fit(matrix);

        Assert.True(model.IsTrained);
        Assert.True(model.PredictOne(new[] { 1.0 }) > model.PredictOne(new[] { -1.0 }));

        var auc = ValidationMetrics.AreaUnderCurve(model.Predict(matrix), matrix.Target);
        Assert.True(auc > 0.95, $"Expected a strong AUC on separable data, got {auc:F3}.");
    }

    [Fact]
    public void PredictionsStayWithinTheUnitInterval()
    {
        var matrix = BuildSmallMatrix();
        var model = new LogisticRegressionModel(iterations: 50);
        model.Fit(matrix);

        Assert.All(model.Predict(matrix), p => Assert.InRange(p, 0.0, 1.0));
    }

    private static FeatureMatrix BuildSmallMatrix() => new(
        new[] { "x" },
        new[] { new[] { -1.0 }, new[] { -0.5 }, new[] { 0.5 }, new[] { 1.0 } },
        new[] { 0, 0, 1, 1 });
}

public class SicrPolicyTests
{
    private static readonly PipelineConfig Config = new();

    [Fact]
    public void NinetyDaysPastDueIsCreditImpaired()
    {
        var scored = Build(pdNow: 0.05, pdAtOrigination: 0.05, daysPastDue: 95);
        Assert.Equal(Ifrs9Stage.Stage3, new SicrPolicy(Config).Assign(scored));
    }

    [Fact]
    public void ThirtyDaysPastDueTriggersTheBackstop()
    {
        var scored = Build(pdNow: 0.05, pdAtOrigination: 0.05, daysPastDue: 35);
        Assert.Equal(Ifrs9Stage.Stage2, new SicrPolicy(Config).Assign(scored));
    }

    [Fact]
    public void DoublingOfPdTriggersStageTwo()
    {
        var scored = Build(pdNow: 0.06, pdAtOrigination: 0.02, daysPastDue: 0);
        Assert.Equal(Ifrs9Stage.Stage2, new SicrPolicy(Config).Assign(scored));
    }

    [Fact]
    public void StablePerformingLoanStaysInStageOne()
    {
        var scored = Build(pdNow: 0.021, pdAtOrigination: 0.020, daysPastDue: 0);
        Assert.Equal(Ifrs9Stage.Stage1, new SicrPolicy(Config).Assign(scored));
    }

    private static ScoredLoan Build(double pdNow, double pdAtOrigination, int daysPastDue) => new()
    {
        Loan = TestData.Loan(daysPastDue: daysPastDue),
        Pd12Month = pdNow,
        PdLifetime = pdNow,
        PdAtOrigination = pdAtOrigination
    };
}

public class EclCalculatorTests
{
    private static readonly PipelineConfig Config = new();

    [Fact]
    public void EclEqualsPdTimesLgdTimesEadDiscounted()
    {
        var scored = new ScoredLoan
        {
            Loan = TestData.Loan(outstandingBalance: 10_000m, termMonths: 12),
            Pd12Month = 0.10,
            PdLifetime = 0.10,
            PdAtOrigination = 0.10,
            Stage = Ifrs9Stage.Stage1
        };

        var result = new EclCalculator(Config).Calculate(scored);
        var expected = (decimal)(0.10 * Config.LossGivenDefault / (1 + Config.DiscountRate)) * 10_000m;

        Assert.Equal(decimal.Round(expected, 2), result.Ecl);
    }

    [Fact]
    public void CreditImpairedExposuresUseAPdOfOne()
    {
        var scored = new ScoredLoan
        {
            Loan = TestData.Loan(outstandingBalance: 5_000m),
            Pd12Month = 0.10,
            PdLifetime = 0.30,
            PdAtOrigination = 0.05,
            Stage = Ifrs9Stage.Stage3
        };

        Assert.Equal(1.0, new EclCalculator(Config).Calculate(scored).Pd);
    }

    [Fact]
    public void SummaryAggregatesByStage()
    {
        var results = new[]
        {
            new EclResult("A", Ifrs9Stage.Stage1, 0.05, 0.65, 1_000m, 30m),
            new EclResult("B", Ifrs9Stage.Stage1, 0.05, 0.65, 1_000m, 40m),
            new EclResult("C", Ifrs9Stage.Stage3, 1.00, 0.65, 2_000m, 900m)
        };

        var summaries = EclCalculator.Summarise(results);

        Assert.Equal(2, summaries.Count);

        var stage1 = summaries.Single(s => s.Stage == Ifrs9Stage.Stage1);
        Assert.Equal(2, stage1.LoanCount);
        Assert.Equal(70m, stage1.TotalEcl);
        Assert.Equal(0.035, stage1.CoverageRatio, 6);
    }
}

public class FeatureBuilderTests
{
    [Fact]
    public void TransformBeforeFitThrows()
    {
        var builder = new FeatureBuilder(new PipelineConfig());
        Assert.Throws<PipelineException>(() => builder.Transform(new[] { TestData.Loan() }));
    }

    [Fact]
    public void FittingOnAnEmptySetThrows()
    {
        var builder = new FeatureBuilder(new PipelineConfig());
        Assert.Throws<DataValidationException>(() => builder.FitTransform(Array.Empty<LoanRecord>()));
    }

    [Fact]
    public void StandardisedNumericColumnsAreCentred()
    {
        var loans = new SyntheticLoanGenerator(count: 500, seed: 3).GetLoans();
        var matrix = new FeatureBuilder(new PipelineConfig()).FitTransform(loans);

        for (var column = 0; column < 6; column++)
        {
            var mean = matrix.Rows.Select(r => r[column]).Average();
            Assert.True(Math.Abs(mean) < 1e-6, $"Column {column} mean was {mean:E2}.");
        }
    }
}

public class SyntheticLoanGeneratorTests
{
    [Fact]
    public void GenerationIsReproducibleForAGivenSeed()
    {
        var first = new SyntheticLoanGenerator(count: 100, seed: 11).GetLoans();
        var second = new SyntheticLoanGenerator(count: 100, seed: 11).GetLoans();

        Assert.Equal(first.Select(l => l.Status), second.Select(l => l.Status));
    }

    [Fact]
    public void WorseGradesDefaultMoreOften()
    {
        var loans = new SyntheticLoanGenerator(count: 20_000, seed: 5).GetLoans();

        var gradeA = loans.Where(l => l.Grade == "A").Average(l => l.DefaultFlag!.Value);
        var gradeE = loans.Where(l => l.Grade == "E").Average(l => l.DefaultFlag!.Value);

        Assert.True(gradeE > gradeA, $"Grade E ({gradeE:P1}) should default more than grade A ({gradeA:P1}).");
    }
}

internal static class TestData
{
    public static LoanRecord Loan(
        int daysPastDue = 0,
        decimal outstandingBalance = 1_000m,
        int termMonths = 36) => new()
    {
        Id = "TEST-1",
        IssueDate = new DateOnly(2015, 6, 1),
        Status = "Fully Paid",
        Grade = "B",
        Purpose = "credit_card",
        TermMonths = termMonths,
        LoanAmount = 10_000m,
        InterestRate = 12.5,
        AnnualIncome = 60_000,
        DebtToIncome = 18.0,
        DelinquenciesLast2Years = 0,
        DaysPastDue = daysPastDue,
        OutstandingBalance = outstandingBalance
    };
}
